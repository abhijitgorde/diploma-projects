package com.datastructure;

import java.util.LinkedList;
import java.util.Scanner;

public class SortgUsingLinkedList {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		/**
		 * Created an empty object of LinkedList (i.e linkedList object don't have any element initially)
		 */
		LinkedList<Integer> linkedList = new LinkedList<>();
		System.out.println("Enter number of elements :: ");

		/**
		 * Create Scanner object to read input from console
		 * linkedListSize object gets LinkedList size to store number of elements which user is going to insert for sorting.
		 * element object gets one by one element from user inside the for loop.
		*/
		Scanner linkedListSize = new Scanner(System.in);
		Scanner element = new Scanner(System.in);

		Integer listSize = linkedListSize.nextInt();

		/**
		 * As user inserts element one by one it is added in linkedlist object
		 */
		for (int j = 1; j <= listSize; j++) {
			System.out.println("Enter Element number " + j + " :: ");
			linkedList.add(new Integer(element.nextInt()));
		}

		/**
		 * below statement prints List of elements that user has entered
		 */
		System.out.println("Entered Elements :: " + linkedList.toString());

		int temp;
		
		/***
		 * Below two for loops does actual sorting using linkedlist
		 * We used swaping logic to sort the element.(Bubble sort)
		 */
		for (int i = 0; i < linkedList.size(); i++) {
			for (int j = i; j < linkedList.size(); j++) {
				if (linkedList.get(i) > linkedList.get(j)) {
					temp = linkedList.get(j);
					linkedList.set(j, linkedList.get(i));
					linkedList.set(i, temp);
				}
			}
		}

		/**
		 * Below print statement prints Sorted linkedlist
		 */
		System.out.println("Sorted Elements :: " + linkedList.toString());

	}

}
