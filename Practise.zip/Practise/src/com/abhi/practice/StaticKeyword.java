package com.abhi.practice;

public class StaticKeyword {


	public static void main(String[] args) {
		//number palindrome
/*		int a=242;
		int n=a, b=a, rev=0;
		
		while(n>0){
			
			a=n%10;
			
			rev=rev*10+a;
			
			n=n/10;
			
			
		}
		
		if(rev == b){
			System.out.println(true);
		}
		else{
			System.out.println(false);
		}*/
		
		
		//fibonasi
/*		int n=10, f0=1, f1=1, f2=0;
		
		for(int i=1;i<=n;i++){
			
			f2=f0+f1;
			
			f0=f1;
			
			f1=f2;
			
			f2=f0;
			
			System.out.println(f2);
		}*/
		
		
/*		// prime number
		
		
		
		
		int n=100;
		int j=0;
		for(int i=1; i<=n;i++){
			
			
			for( j=2;j<=i;j++){
				
				if(i%j == 0){
					break;
				}
			}
			
			if(i==j){
				System.out.println(i);
			}
		}*/
		
		
	/*	int n=6;
		
		if(n%2 != 0){
			System.out.println("prime");
		}else{
			System.out.println("not prime");
		}
		*/
		
		
		
		
		
		//pattern 1
	/*	for(int i=0;i<=6;i++){
			
			for(int j=1;j<=i;j++){
				System.out.print("*");
			}
			System.out.println("");
		}*/
		
		
		//pattern 2
	/*	for(int i=6;i>=0;i--){
			
			for(int j=1;j<=i;j++){
				System.out.print("*");
			}
			System.out.println("");
			
		}
		*/
		
		// pattern 3
		
		for(int i=0;i<=10;i++){
			
			for(int k=i;k<=10;k++){
				System.out.print(" ");
			}
			
			for(int j=0;j<=i;j++){
				System.out.print("* ");
			}
			System.out.println("");
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}