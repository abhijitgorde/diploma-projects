package com.abhi.practice;

import java.util.Scanner;

public class swapingWithoutUsingThordVariable {
	static int n;
	int cnt=0,reverse=0;
	public void isPrime(int n){
		for(int i=2;i<n/2+1;i++){
			if(n%i==0)
			{
			System.out.println("not a prime");
			cnt++;
			break;
			}
		}
		if(cnt==0){
			System.out.println("prime");
		}
		while(n!=0){
			reverse = reverse*10+n%10;
			n=n/10;
			}
		System.out.println(reverse);
	}

	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a no");
		n= sc.nextInt();
		swapingWithoutUsingThordVariable s= new swapingWithoutUsingThordVariable();
		s.isPrime(n);
		
	}
}
