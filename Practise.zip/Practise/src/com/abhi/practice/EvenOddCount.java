package com.abhi.practice;

public class EvenOddCount {

	
	
	public static void main(String[] args) {

		int even=0;
		int odd=0;
		
		for(int i=1;i<=11;i++){
			
			if(i %2 ==0){
				even++;
			}else{
				odd++;
			}
			
			
		}
		
		System.out.println(even);
		System.out.println(odd);
		
	}

}
