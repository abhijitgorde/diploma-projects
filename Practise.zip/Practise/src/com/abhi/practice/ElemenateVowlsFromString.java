package com.abhi.practice;

import java.util.ArrayList;
import java.util.List;

/*
 *Eleminate Vowels fro Given String 
 * 
 */
public class ElemenateVowlsFromString {
	
	private String check(String str){
		int i=0;
		List<Character> list=new ArrayList<>();
		Character[] stringArr=new Character[str.length()];
		String resultString="";
		for(i=0;i<str.length();i++){
			stringArr[i]=str.charAt(i);
			list.add(stringArr[i]);
		}
		
		for(Character c: list){
			
			if(c.equals('a') || c.equals('e') || c.equals('i')|| c.equals('o')|| c.equals('u')){
				continue;
			}
			resultString +=c;
			 
		}
		int count=resultString.length();
		 
		return resultString;
	}

	public static void main(String[] args) {

		ElemenateVowlsFromString m=new ElemenateVowlsFromString();
		String a="blklaainqrst";
		System.out.println("string "+ m.check(a));
	}

}
