package com.abhi.practice;

public class Factorial {

}
