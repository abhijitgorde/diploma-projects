package com.abhi.practice;

import java.util.Scanner;

public class RevStr {
	String rev = "";

	public String revStr(String str){

		if(str.length()==0|| str==null){
		
		}
		else{
			rev = rev + str.charAt(str.length()-1);
			//System.out.println(rev);
			revStr(str.substring(0,str.length()-1));
		}
		return rev;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	System.out.println("enter string");
	String str;
	str=sc.nextLine();
	RevStr r= new RevStr();
	System.out.println(r.revStr(str));
	}
}
