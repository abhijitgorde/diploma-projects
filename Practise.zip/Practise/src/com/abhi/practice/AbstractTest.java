package com.abhi.practice;

public   class AbstractTest {
	
	 static void abc(){
		 
	 }

}
