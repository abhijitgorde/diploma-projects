package com.abhi.practice;

public class Test2 {

	public static void main(String[] args) {

		
		
		Long mili=20000L;
		
	int min=(int) ((mili/60*1000))%60;
	
	System.out.println(min);
	}

}
