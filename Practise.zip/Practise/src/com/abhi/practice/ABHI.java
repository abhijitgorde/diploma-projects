package com.abhi.practice;

import java.util.Date;

final class E implements Cloneable{
	
private final Integer id;
private final Double percent;
private final Date dob;

public E(Integer id, Double percent, Date dob) {
	super();
	this.id = id;
	this.percent = percent;
	this.dob = dob;
}

public Integer getId() {
	return id;
}

public Double getPercent() {
	return percent;
}

public Date getDob() {
	return dob;
}



@Override
protected Object clone() throws CloneNotSupportedException {
	E e=new E(id, percent, dob);
	
	return e;
}



	
}



public class ABHI {

	public static void main(String[] args) {

		
	}

}
