package com.abhi.practice;

public class Test1 {
	String s= new String("sai");
	String s1="sai";
	String s3 = "sai";
	String s2= new String("sai");
	public void p(){
	System.out.println(s.equals(s1));
	System.out.println(s==s2);
	System.out.println(s==s1);
	System.out.println(s1==s3);
	int i = 203000000;
	Integer j = new Integer(203000000);
	System.out.println(i==j);
	}
	public static void main(String args[]){
		Test1 t=new Test1();
		t.p();

	}
}
