package com.abhi.practice;

public class PrintStar {

	
	
	/* 			    *
	 * 			   * *
	 *            * * *
	 *           * * * *
	 *          * * * * *      
	 */
	
	
	/*
	 *      *
	 		**
	 		***
	 		*****
	 		****** 
	 		*******
	 		********
	 */
	private static void star1(){
		
		  int i, j;
	        for(i=0; i<5; i++)
	        {
	            for(j=0; j<=i; j++)
	            {
	                System.out.print("* ");
	            }
	            System.out.println();
	        }
		
	}
	
	private static void star2(){
		
		  int i, j;
	        for(i=5; i<=0; i--)
	        {
	            for(j=5; j>=i; j--)
	            {
	                System.out.print("* ");
	            }
	            System.out.println();
	        }
		
	}
	public static void main(String[] args) {
		star1();
		star2();
	}
}
