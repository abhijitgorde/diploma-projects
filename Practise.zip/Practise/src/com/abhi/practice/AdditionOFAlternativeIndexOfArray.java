package com.abhi.practice;

import java.util.ArrayList;

public class AdditionOFAlternativeIndexOfArray {
	
	int given[]={1,2,3,4,5,6};
	ArrayList<Integer> result=new ArrayList<>();
	
	private void manipulate(){
		
	int first;
	int prev;
	int current = 0;
	int j=1;
	
		for(int i=0;i<given.length;i++){
			
			
			first=given[i];
			if(i <=given.length-1){
				current=given[i+1];
			}
			
			i++;
			result.add(first+current);
			
			
		}
	
	
		
		System.out.println(result);
		
		
		
	}
	
	public static void main(String[] args) {
	
		AdditionOFAlternativeIndexOfArray a=new AdditionOFAlternativeIndexOfArray();
		a.manipulate();
	}

}
