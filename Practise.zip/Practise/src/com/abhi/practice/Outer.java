package com.abhi.practice;

public class Outer {
static int a=10;
public void pr(){
	Outer o=new Outer();
	System.out.println(o.a);

}
	public static class Inner{
		int b=-10;
		public static void say(){
		System.out.println(a);	
		}
		}
		public static void main(String args[]){
		Outer o = new Outer();	
		Outer.Inner i = new Outer.Inner();
		Inner.say();
		System.out.println(i.b);
	}
}
